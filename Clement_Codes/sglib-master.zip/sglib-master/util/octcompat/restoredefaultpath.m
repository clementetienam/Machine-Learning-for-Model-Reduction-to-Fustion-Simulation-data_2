function restoredefaultpath
path(pathdef);
