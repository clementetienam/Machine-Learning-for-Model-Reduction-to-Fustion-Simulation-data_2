function stack=dbstack()
warning('octave has no dbstack function');
stack={};
